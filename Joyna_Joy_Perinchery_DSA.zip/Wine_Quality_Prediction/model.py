import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df=pd.read_csv('winequality-red.csv')
print(df.head())

df.info()
df.isnull().sum()
df.min()
df.max()

# Features and target
X = df.drop('quality', axis=1)
y = df['quality'].apply(lambda x: 'low' if x <= 4 else 'medium' if x <=6 else 'high')

sns.countplot(data=y)
plt.title("Distribution of Quality Labels")
plt.show()



# **StandardScaler**
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Spilting Dataset
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# **Train model**
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(n_estimators=150, class_weight='balanced', random_state=42)
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# Evaluation
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

import pickle

# Save trained scaler
with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)
    
# Save trained model
with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)
    
